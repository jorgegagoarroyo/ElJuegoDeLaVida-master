var piezas = [
    {
        nombre:"Unit",
        array:
        [
            [true]
        ]
    },
    {
        nombre:"Block",
        array:
        [
            [true,true],
            [true,true]
        ]
    },
    {
        nombre:"Boat",
        array:
        [
            [true,true,false],
            [true,false,true],
            [false,true, false]
        ]
    },
    {
        nombre:"Blinker",
        array:
        [
            [true,true,true]
        ]
    },
    {
        nombre:"Toad",
        array:
        [
            [false,true,true,true],
            [true,true,true,false]
        ]
    },
    {
        nombre:"Glinder",
        array:
        [
            [true,true,true],
            [true,false,false],
            [false,true, false]
        ]
    }   
]


/*
{
        nombre:"",
        array:
        [
            [false,true,false],
            [false,true,false],
            [false,true, false]
        ]
    },
*/